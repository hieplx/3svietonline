<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('buses', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->unsignedBigInteger('cartype_id')->nullable();
            $table->unsignedBigInteger('car_id')->nullable();
            $table->string('image')->nullable();
            $table->integer('seat')->default(0);
            $table->integer('price')->default(0);
            $table->string('startPointName')->nullable();
            $table->integer('startPointId')->nullable();
            $table->string('endPointName')->nullable();
            $table->integer('endPointId')->nullable();
            $table->integer('startWard_id')->nullable();
            $table->string('startWard_name')->nullable();
            $table->integer('startDisrict_id')->nullable();
            $table->string('startDistrict_name')->nullable();
            $table->integer('endWard_id')->nullable();
            $table->string('endWard_name')->nullable();
            $table->integer('endDisrict_id')->nullable();
            $table->string('endDistrict_name')->nullable();
            $table->string('detailAddressStart');
            $table->string('detailAddressEnd');
            $table->integer('seat_empty');
            $table->date('date_active');
            $table->date('date_inactive')->nullable();
            $table->string('start_time');
            $table->string('range_time');
            $table->string('end_time');
            $table->string('status')->default('ACTIVED');
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('buses');
    }
}
