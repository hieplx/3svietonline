import React from 'react'
import HttpClient from '../api/axiosClient'
import { API_PAYMENT_TYPE } from '../config'

export const paymentService ={
    getAllPaymenttype(){
        return HttpClient.get(`${API_PAYMENT_TYPE}`)
    },
    addPaymenttype(data) {
        return HttpClient.post(`${API_PAYMENT_TYPE}`, data)
    },
    updatePaymenttype(id ,data) {
        return HttpClient.put(`${API_PAYMENT_TYPE}/${id}`, data)
    },
    deletePaymenttype(id) {
        return HttpClient.delete(`${API_PAYMENT_TYPE}/${id}`)
    },
    getDetail(id){
        return HttpClient.get(`${API_PAYMENT_TYPE}/${id}`)
    }
}
