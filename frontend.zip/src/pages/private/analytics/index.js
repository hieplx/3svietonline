import React, { useState } from "react";
import Modal from "./Modal";
import TabList from "./TabListt";
const Analytics = () => {
  return (
    <div>
      <TabList />
    </div>
  );
};

export default Analytics;
