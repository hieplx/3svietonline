import { faEdit, faPowerOff, faTrash, faCheck } from "@fortawesome/fontawesome-free-solid";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import styled from "styled-components";
import Table from "../../../compornent/admin/table";
import { getAllRating } from "../../../redux/actions/rating";
import { getAllPaymenttype } from "../../../redux/actions/paymenttype";
import moment from "moment";
import alertify from "alertifyjs";
import { paymentService } from "../../../service/paymenttype";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
const PaymentType = () => {
    const TableStyled = styled.div`
  .rt-th:first-child {
    display: none;
  }
  .rt-td:first-child {
    display: none;
  }
  .rt-td{
    display: flex;
    justify-content: center;
    align-items: center;
    height: 200px;
  }
`;
    const dispatch = useDispatch();
    const history = useHistory()

    const { payments } = useSelector((state) => state.payment);
    const [dispatchDependency, setDispatchAcitive] = useState(0);
    const dependencies = [payments.length, dispatchDependency];

    const reloadActiveAPI = () => {
        setDispatchAcitive((pre) => ++pre);
    };
    const handleDeletePayment = (id) => {
        alertify
            .confirm("Bạn có chắc chắn muốn xoá phương thức này ?", async function () {
                const res = await paymentService.deletePaymenttype(id);
                if (res.status === 200) {
                    reloadActiveAPI();
                    alertify.success("Xoá thành công");
                } else {
                    alertify.warning("Có lỗi xảy ra");
                }
            })
            .set({ title: "Chuyến xe" })
            .set("movable", false)
            .set("ok", "Alright!")
            .set("notifier", "position", "top-right");
    };
    const [columns, setColumns] = useState([
        {
            Header: "Mã",
            accessor: "id",
            maxWidth: 100,
            filterable: true,
            show: true,
        },
        {
            Header: "Hình ảnh",
            accessor: "rating_point",
            //   maxWidth: 300,
            //   height : 300,
            //   filterable: true,
            show: true,
            Cell: ({ original }) => {
                return (
                    <img src={original?.qr_code} width={200} alt="" srcset="" />
                );
            },
        },
        {
            Header: "Tên",
            accessor: "name",
            //   maxWidth: 300,
            filterable: true,
            show: true,
        },
        {
            Header: "Chủ tài khoản",
            accessor: "customer",
            //   maxWidth: 300,
            filterable: true,
            show: true,
        },
        {
            Header: "Số tài khoản",
            accessor: "stk",
            filterable: true,
            show: true,
        },
        {
            Header: "Chi nhánh",
            accessor: "cn",
            //   maxWidth: 300,
            filterable: true,
            show: true,
        },
        {
            Header: "Ngày tạo",
            accessor: "rating_time",
            //   maxWidth: 200,
            //   filterable: true,
            show: true,
            Cell: ({ original }) => {
                return (
                    <span>{moment(original.created_at).format('H:mm DD-MM-YYYY')}</span>
                );
            },
        },
        {
            Header: "Hành động",
            accessor: "rating_time",
            // maxWidth: 200,
            // filterable: true,
            show: true,
            Cell: ({ original }) => {
                return (
                    <div className="tw-flex tw-justify-center tw-gap-[20px]">
                        <button
                            onClick={() => history.push(`/admin/payment-type/edit/${original.id}`)}
                        >
                            <FontAwesomeIcon icon={faEdit} color="blue" />
                        </button>

                        <button onClick={() => handleDeletePayment(original.id)}>
                            <FontAwesomeIcon icon={faTrash} color="red" />
                        </button>
                    </div>
                );
            },
        },
    ]);

    useEffect(() => {
        dispatch(getAllPaymenttype());
    }, [dispatchDependency]);
    return (
        <div>
            <div className="tw-mb-4 tw-flex tw-justify-between tw-items-center">
                <div>
                    <span className="tw-uppercase tw-text-2xl">Thanh toán</span>
                </div>
                <button
                    className="tw-bg-green-600 tw-text-white active:tw-bg-pink-600 tw-font-bold tw-uppercase tw-text-xs tw-px-4 tw-py-2 tw-rounded tw-shadow hover:tw-shadow-md tw-outline-none focus:tw-outline-none tw-mr-1 tw-ease-linear tw-transition-all tw-duration-150"
                    type="button"
                    onClick={() => {
                        history.push("/admin/payment-type/add");
                    }}
                >
                    Thêm phương thức
                </button>
            </div>
            <TableStyled>
                <Table
                    data={payments}
                    columns={columns}
                />
            </TableStyled>

        </div>
    );
};

export default PaymentType;
