import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form';
import { useHistory, useParams } from 'react-router-dom/cjs/react-router-dom.min';
import firebase from '../../../../firebase';
import Input from '../../../../compornent/admin/input/Input';
import SelectForm from '../../../../compornent/selectForm';
import { paymentService } from '../../../../service/paymenttype';

const AddPaymenttype = () => {
    const _currentImage = "https://firebasestorage.googleapis.com/v0/b/headphone-899cc.appspot.com/o/buses%2F15928210953282.jpeg?alt=media&token=549e1411-9155-41a6-a6d3-f8e2e9ebaef8"
    const [fileName, setFileName] = useState("");
    const [urlImage, setUrlImage] = useState("https://firebasestorage.googleapis.com/v0/b/headphone-899cc.appspot.com/o/buses%2F15928210953282.jpeg?alt=media&token=549e1411-9155-41a6-a6d3-f8e2e9ebaef8");
    const history = useHistory();
    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        reset,
        watch,
        control,
    } = useForm({
        defaultValues: {
            name: '',
            stk: '',
            customer: '',
            cn: '',
            type: 'ATM'

        }
    });
    const { id } = useParams()
    const handleChangeImage = (e) => {
        const file = e.target.files[0];
        setFileName(file.name);
        let storeRef = firebase.storage().ref(`qrcode/${file.name}`);
        storeRef.put(file).then((e) => {
            storeRef.getDownloadURL().then(async (url, e) => {
                setUrlImage(url);
                setValue('qr_code' , url)
            });
        });
    };
    const typesArr = [
        {
            value: 'OFFLINE',
            label: 'Trực tiếp',
        },
        {
            value: 'ATM',
            label: 'Chuyển khoản'
        }
    ]
    const handleSubmitForm = async (data) => {
        if (id ) {
            const res = await paymentService.updatePaymenttype(id ,data)
            if (res.status === 200) {
                history.push('/admin/payment-type')
            }
        }else{
            const res = await paymentService.addPaymenttype(data)
            if (res.status === 200) {
                history.push('/admin/payment-type')
            }
        }
       
    }
    const handleChange = (data) => {
        setValue('type', data.value)
    }
    useEffect(() => {
        const getItem = async () => {
            const res = await paymentService.getDetail(id)
            if (res.status === 200) {
                const {name , qr_code , stk , type , cn , customer}  = res.data
                setValue('name' , name)
                setValue('qr_code' , qr_code)
                setValue('stk' , stk)
                setValue('type' , type)
                setValue('cn' , cn)
                setValue('customer' , customer)
            }
        }
        if (id) {
            getItem()
        }
    }, [id])

    return (
        <>
            <div>
                <section className="bg-blueGray-50">
                    <div className="">
                        <div className="tw-relative tw-flex tw-flex-col tw-min-w-0 tw-break-words tw-w-full tw-mb-6 tw-shadow-lg tw-rounded-lg bg-blueGray-100 tw-border-0">
                            <div className="tw-rounded-t tw-bg-white tw-mb-0 tw-px-6 tw-py-6 ">
                                <div className="tw-text-center tw-flex tw-justify-between">
                                    <span className="tw-uppercase tw-text-2xl">{id ? "Sửa phương thức" : "Thêm phương thức"}</span>
                                    <button
                                        className="tw-bg-green-600 tw-text-white active:tw-bg-pink-600 tw-font-bold tw-uppercase tw-text-xs tw-px-4 tw-py-2 tw-rounded tw-shadow hover:tw-shadow-md tw-outline-none focus:tw-outline-none tw-mr-1 tw-ease-linear tw-transition-all tw-duration-150"
                                        type="button"
                                        onClick={() => {
                                            history.push("/admin/payment-type");
                                        }}
                                    >
                                        Quay lại
                                    </button>
                                </div>
                            </div>
                            <div className=" tw-flex-auto lg:tw-px-3">
                                <form onSubmit={handleSubmit(handleSubmitForm)}>


                                    <div className="tw-mb-2 tw-flex tw-justify-between lg:tw-px-3 tw-px-3 tw-gap-2">
                                        <div className="tw-w-full tw-flex tw-flex-wrap">
                                            <div className="tw-w-full lg:tw-w-5/12">
                                                <img
                                                    src={`${urlImage !== null
                                                        ? urlImage
                                                        : _currentImage
                                                        }`}
                                                    className="tw-h-[339px]"
                                                />
                                            </div>
                                            <div className="lg:tw-w-7/12">
                                                <div className="tw-py-20 tw-h-[339px] tw-bg-gray-300 tw-px-2">
                                                    <div className="tw-max-w-md tw-mx-auto tw-bg-white tw-rounded-lg tw-overflow-hidden md:tw-max-w-lg">
                                                        <div className="md:tw-flex">
                                                            <div className="tw-w-full">
                                                                <div className="tw-p-3">
                                                                    <div className="tw-mb-2">
                                                                        {" "}
                                                                        <div className="tw-relative tw-h-40 tw-rounded-lg tw-border-dashed tw-border-2 tw-border-gray-200 tw-bg-white tw-flex tw-justify-center tw-items-center hover:tw-cursor-pointer">
                                                                            <div className="tw-absolute">
                                                                                <div className="tw-flex tw-flex-col tw-items-center ">
                                                                                    {" "}
                                                                                    <span>{fileName}</span>
                                                                                    <i className="fa fa-cloud-upload fa-3x tw-text-gray-200" />{" "}
                                                                                    <span className="tw-block tw-text-blue-400 tw-font-normal">
                                                                                        Tải ảnh lên
                                                                                    </span>{" "}
                                                                                </div>
                                                                            </div>{" "}
                                                                            <input
                                                                                onChange={handleChangeImage}
                                                                                type="file"
                                                                                className="tw-h-full tw-w-full tw-opacity-0"
                                                                                name
                                                                            />
                                                                        </div>
                                                                        <div className="tw-flex tw-justify-between tw-items-center tw-text-gray-400">
                                                                            {" "}
                                                                            <span>
                                                                                Tải lên tệp tin định dạng : .img, .png, jpeg
                                                                            </span>{" "}
                                                                            <span className="tw-flex tw-items-center ">
                                                                                <i className="fa fa-lock tw-mr-1" />{" "}
                                                                                secure
                                                                            </span>{" "}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>




                                    <div className="tw-flex tw-flex-wrap tw-mt-5">
                                        <div className="tw-w-full lg:tw-w-6/12 tw-px-4">
                                            <div className="tw-relative tw-w-full tw-mb-3">
                                                <Input
                                                    lable="Tên phương thức"
                                                    placeholder="Tên phương thức"
                                                    type="text"
                                                    register={register}
                                                    fieldName={"name"}
                                                    errors={errors}
                                                    required={true}
                                                    messageErrors={"Vui lòng nhập thông tin"}
                                                />
                                            </div>
                                        </div>
                                        <div className="tw-w-full lg:tw-w-6/12 tw-px-4 tw-mb-3">
                                            <div className="tw-relative tw-w-full tw-mb-3">
                                                <Input
                                                    lable="Số tài khoản"
                                                    placeholder="Số tài khoản"
                                                    type="text"
                                                    register={register}
                                                    fieldName={"stk"}
                                                    errors={errors}
                                                    required={true}
                                                    messageErrors={"Vui lòng nhập thông tin"}
                                                />
                                            </div>
                                        </div>
                                    </div>


                                    <div className="tw-flex tw-flex-wrap  tw-mt-5">
                                        <div className="tw-w-full lg:tw-w-4/12 tw-px-4">
                                            <div className="tw-relative tw-w-full tw-mb-3">
                                                <Input
                                                    lable="Chủ tài khoản  "
                                                    placeholder="Chủ tài khoản"
                                                    type="text"
                                                    register={register}
                                                    fieldName={"customer"}
                                                    errors={errors}
                                                    required={true}
                                                    messageErrors={"Vui lòng nhập thông tin"}
                                                />
                                            </div>
                                        </div>
                                        <div className="tw-w-full lg:tw-w-4/12 tw-px-4">
                                            <div className="tw-relative tw-w-full tw-mb-3">
                                                <Input
                                                    lable="Chi nhánh"
                                                    placeholder="Chi nhánh"
                                                    type="text"
                                                    register={register}
                                                    fieldName={"cn"}
                                                    errors={errors}
                                                    required={true}
                                                    messageErrors={"Vui lòng nhập thông tin"}
                                                />
                                            </div>
                                        </div>
                                        <div className="tw-w-full lg:tw-w-4/12 tw-px-4 tw-mb-3">
                                            <div>
                                                <label
                                                    className="tw-block tw-uppercase  text-blueGray-600 tw-text-xs tw-font-bold tw-mb-2"
                                                    htmlfor="grid-password"
                                                >
                                                    Loại phương thức
                                                </label>
                                                <SelectForm options={typesArr} defaultValues={typesArr.find(_elt => _elt.value === watch('type'))} placeholder={'Chọn loại'} onChange={handleChange} errors={errors} fieldName={'type'} register={register} />
                                            </div>
                                        </div>
                                    </div>
                                    <footer className="">
                                        <div className="container tw-mx-auto tw-px-4">
                                            <div className="tw-flex tw-flex-wrap tw-items-center md:tw-justify-end tw-justify-center tw-mb-10 tw-gap-5">
                                                <button
                                                    type="submit"
                                                    className="sm:tw-w-full md:tw-w-full lg:tw-w-[200px] tw-bg-green-600 tw-transform tw-p-3 tw-text-white tw-text-md hover:tw-bg-gray-800 tw-font-bold tw-rounded-lg"
                                                >
                                                    {id ? 'Cập nhật' : 'Tạo mới'}
                                                </button>
                                            </div>
                                        </div>
                                    </footer>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </>
    )
}

export default AddPaymenttype