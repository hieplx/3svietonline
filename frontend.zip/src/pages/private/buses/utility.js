export const BUSES_STATUS_FILTER  = [
    {
        type : "ACTIVED" , 
        name : "Đang hoạt động"
    },
    {
        type : "WAITING_ACTIVE" , 
        name : "Dừng hoạt động"
    }
]