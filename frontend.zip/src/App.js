import Routes from "./router";
import 'alertifyjs/build/css/alertify.css';
import  './App.css'
import "react-datepicker/dist/react-datepicker.css";
function App() {
  return  <Routes />  
 
}

export default App;
