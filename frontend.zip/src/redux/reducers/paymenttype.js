import { ACTION_GET_ALL_PAYMENT_TYPE } from "../actions/paymenttype";

const initialState = {
    payments : []
}

const paymenttypeReducers = (state = initialState, action) => {
    switch (action.type) {
      case ACTION_GET_ALL_PAYMENT_TYPE:
        return {
          ...state,
          payments: action.payload || [],
        };
      default:
        return state;
    }
  };
  
  export default paymenttypeReducers;