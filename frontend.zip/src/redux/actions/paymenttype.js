import { paymentService } from "../../service/paymenttype"
import { ratingService } from "../../service/rating"

export const ACTION_GET_ALL_PAYMENT_TYPE = "ACTION_GET_ALL_PAYMENT_TYPE"

export const getAllPaymenttype = () =>{
    return async (dispatch) =>{
        const res = await paymentService.getAllPaymenttype()
        if (res.status === 200) {
            dispatch({
                type : ACTION_GET_ALL_PAYMENT_TYPE , 
                payload : res.data || []
            })
        }
    }
}