import styled from "styled-components";
import React from 'react'
const ButtonStyle = styled.button`
border : none
`



const Button = () => {
      return (
            <ButtonStyle>
                  
            </ButtonStyle>
      )
}

export default Button
